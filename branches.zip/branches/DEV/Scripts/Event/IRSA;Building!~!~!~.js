//IRSA;Building!~!~!~^`
showDebug = true;
showMessage = true;

	if (inspType == "Building Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Electrical Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Plumbing Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Mechanical Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Sign Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Roof Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Fence Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Grading Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete","Updated by Inspection Result","Note");
	}

if (inspType == "Solar Final" && inspResult == "Completed") {
	closeTask("Inspection","Final Inspection Complete", "Updated by Inspection Result","Note");
	}