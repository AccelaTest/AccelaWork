 // WTUA;ENVHEALTH!~!~!~ 
if (matches(appTypeArray[1],'EHSM','HHECMSC','HOUSING')) { //07/13/17 chaas: Filter for these three appTypes only, per Lily Cheng
if (capName == '') {
	
//replaced branch(ES_GET_ADDRESS)
ES_GET_ADDRESS();
	}
}
