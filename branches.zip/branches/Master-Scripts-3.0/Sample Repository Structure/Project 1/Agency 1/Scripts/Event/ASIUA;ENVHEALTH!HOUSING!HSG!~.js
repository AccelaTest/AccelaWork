// ASIUA;ENVHEALTH!HOUSING!HSG!~
HEHS = 'RVOLLER';
if (AInfo['Bed Bugs'] == 'Yes' && AInfo['Bed Bugs Referred'] == null) {
	
//replaced branch(ES_BBE_CREATE_CHILD_CASE)
ES_BBE_CREATE_CHILD_CASE();
	}
