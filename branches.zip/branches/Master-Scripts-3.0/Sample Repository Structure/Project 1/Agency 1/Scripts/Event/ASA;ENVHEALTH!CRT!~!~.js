// ASA;ENVHEALTH!CRT!~!~ 
// 7/5/17 The user MSTEINER is not in MCPHD configuration
assignCap('MSTEINBR');
updateAppStatus('Legal Review','Initial status'); //verified app status
updateWorkDesc('Environmental Court');
