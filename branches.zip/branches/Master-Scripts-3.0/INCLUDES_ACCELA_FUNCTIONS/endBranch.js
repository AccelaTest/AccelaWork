function endBranch() {
	//    stop execution of the current std choice
	stopBranch = true;
	}