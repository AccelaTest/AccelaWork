function branch(stdChoice)
	{
	doStandardChoiceActions(stdChoice,true,0);
	}
 
